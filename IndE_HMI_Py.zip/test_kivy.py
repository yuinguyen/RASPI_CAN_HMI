from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.core.window import Window

class SimpleTestApp(App):
    def build(self):
        # Set window to blue to match your app
        Window.clearcolor = (0, 0.75, 0.75, 1)
        
        # Create a label with absolute position
        label = Label(
            text="TEST TEXT",
            font_size=50,
            color=(1, 0, 0, 1),  # Bright red text
            pos=(100, 200),  # Position near center
            size_hint=(None, None),
            size=(400, 100)
        )
        
        # Create a button with absolute position
        button = Button(
            text="BUTTON",
            font_size=30,
            background_color=(1, 1, 1, 1),  # White button
            color=(0, 0, 0, 1),  # Black text
            pos=(100, 100),
            size_hint=(None, None),
            size=(200, 80)
        )
        
        # Add widgets to window
        Window.add_widget(label)
        Window.add_widget(button)
        
        return None  # We're adding widgets directly to Window

if __name__ == '__main__':
    SimpleTestApp().run()
