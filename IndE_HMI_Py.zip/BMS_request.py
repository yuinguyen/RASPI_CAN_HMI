import sys
import time
from can_driver import CAN_1, CanError, CAN_SPEED, CAN_CLOCK, CanMsg, CanMsgFlag
import struct
from typing import Dict,List,Tuple,Union,Optional
import DataLog 
SPI0_CE0_PIN = 8
SPI0_CE1_PIN = 7


log = DataLog._Datalog()
logBat = DataLog._BatteryPair(0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8)
can = CAN_1(board="RaspberryPi4", spics=SPI0_CE0_PIN)

class _BMS_request:
    def __init__(self):
        pass
    def setupCAN(self):
        # Setup
        #can = CAN_1(board="RaspberryPi4", spics=SPI0_CE0_PIN) 
        # Initialize - default 250kbps @ CAN module crystal frequency = 8MHz, change if network uses a different baudrate
        # or module uses a different crystal clk source
        ret = can.begin(bitrate=CAN_SPEED.CAN_250KBPS,canclock=CAN_CLOCK.MCP_8MHZ)
        if ret != CanError.ERROR_OK:
            print("Error initializing CAN!")
            sys.exit(1)
        print("Initialized successfully!")
    def sendExtendedRequest(self, can_id = 0x18900140, can_id_reply = 0x18904001, data = 0x0, timeout = 1.0):
        #can_id = f"{priority}{data_id}{bms_address}{pc_address}"
        #can_id = (priority << 26) | (data_id << 18) | (bms_address << 14) | (pc_address << 10)
        #can_id_hex = can_id.encode('utf-8').hex()
        #data_id_hex = format(data_id, '02x')
        #priority_hex = format(priority, '02x')
        #bms_address_hex = format(bms_address, '02x')
        #pc_address_hex = format(pc_address, '02x')
        #can_id = f"{priority_hex}{data_id_hex}{bms_address_hex}{pc_address_hex}"
        #can_id_int = int(can_id)
        #can_id_hex = int(hex(can_id_int), 16)
        #can_id_int = int(can_id_hex)
        #can_id_hex = format(can_id_int, 'x')

        ext_frame = CanMsg(can_id=can_id, flags=CanMsgFlag.EFF) #extended frame
        error = can.send(ext_frame)
        if error == CanError.ERROR_OK:
            print("can id sent: ",hex(can_id))
        else:
            print('failed sent')
        start_time = time.time()
        while time.time() - start_time < timeout:
            if can.checkReceive():
                error, msg = can.recv()
                if error == CanError.ERROR_OK and msg.can_id == can_id_reply:
                    return msg.data #maybe add .hex()?
    def receive_can(self):
        # Receive loop
        print("Waiting for CAN messages...")
        try:
            if can.checkReceive():
                error, msg = can.recv()
                if error == CanError.ERROR_OK:
                    print('------------------------------')
                    print("CAN ID: %#x" % msg.can_id)
                    print("Is RTR frame:", msg.is_remote_frame)
                    print("Is EFF frame:", msg.is_extended_id)
                    print("CAN data hex:", msg.data.hex())
                    print("CAN data dlc:", msg.dlc)
                #return 
        except KeyboardInterrupt:
            print("\nExiting...")
class _DalyBMS:
    BMS_ADDR = 0x01
    PC_ADDR = 0x40
    req = _BMS_request()
    # Data IDs for different message types
    DATA_ID = {
        "TOTAL_VOLTAGE": 0x18900140,
        "CELL_VOLTAGES": 0x18910140,
        "TEMPERATURES": 0x18920140,
        "MOSFET_STATUS": 0x18930140,
        "STATUS_INFO": 0x18940140,
        "CELL_VOLTAGES_RANGE": 0x18950140,
        "TEMPERATURE_RANGE": 0x18960140,
        "BALANCE_STATE": 0x18970140,
        "FAILURE_STATUS": 0x18980140,
        "DISCHARGE_MOS_CONTROL": 0x18D90140,
        "CHARGE_MOS_CONTROL": 0x18DA0140
    }
    DATA_ID_REPLY = {
        "TOTAL_VOLTAGE": 0x18904001,
        "CELL_VOLTAGES": 0x18914001,
        "TEMPERATURES": 0x18924001,
        "MOSFET_STATUS": 0x18934001,
        "STATUS_INFO": 0x18944001,
        "CELL_VOLTAGES_RANGE": 0x18954001,
        "TEMPERATURE_RANGE": 0x18964001,
        "BALANCE_STATE": 0x18974001,
        "FAILURE_STATUS": 0x18984001,
        "DISCHARGE_MOS_CONTROL": 0x18D94001,
        "CHARGE_MOS_CONTROL": 0x18DA4001
    }
    def __init__(self):
        pass
    def get_basic_info(self) -> Dict[str, Union[float, int]]:
        """
        Get basic information from the BMS (total voltage, current, SOC)
        
        Returns:
            Dict containing total_voltage, current, and soc
        """
        data = self.req.sendExtendedRequest(can_id = self.DATA_ID["TOTAL_VOLTAGE"],can_id_reply =  self.DATA_ID_REPLY["TOTAL_VOLTAGE"], data=0x0, timeout = 0.5)

        if data is None:
            return {}
        log._BatteryCurrent._value =  (struct.unpack(">H", data[4:6])[0] - 30000) * 0.1 # 0.1A with 30000 offset
        logBat._Capacity = struct.unpack(">H", data[6:8])[0] * 0.1 # 0.1% scale
        result = {
            "total_voltage": struct.unpack(">H", data[0:2])[0] * 0.1,  # 0.1V scale
            "current": log._BatteryCurrent._value,  
            "soc": logBat._Capacity
        }
        
        #self._last_data.update(result)
        print(result)
        return result
          
#     def get_cell_voltages(self) -> Dict[str, Union[float, int, List]]:
#         """
#         Get information about cell voltages (min, max, difference)
#         
#         Returns:
#             Dict containing max_cell_voltage, max_cell_number, 
#                         min_cell_voltage, min_cell_number, voltage_diff
#         """
#         data = _BMS_request.sendExtendedRequest(self.DATA_ID["CELL_VOLTAGES",self.DATA_ID_REPLY["CELL_VOLTAGES"], timeout = 0.5)
#         if data is None:
#             return {}
#             
#         result = {
#             "max_cell_voltage": struct.unpack(">H", data[0:2])[0],  # mV
#             "max_cell_number": data[2],
#             "min_cell_voltage": struct.unpack(">H", data[3:5])[0],  # mV
#             "min_cell_number": data[5],
#             "voltage_diff": struct.unpack(">H", data[6:8])[0]  # mV
#         }
#         
#         self._last_data.update(result)
#         return result
      
    def get_temperatures(self) -> Dict[str, Union[float, int]]:
        """
        Get temperature information
        
        Returns:
            Dict containing max_temp, max_temp_number, min_temp, min_temp_number,
                        mos_temp, board_temp, temp_diff
        """
        data = _BMS_request.sendExtendedRequest(self.DATA_ID["TEMPERATURES"], self.DATA_ID_REPLY["TEMPERATURES"], timeout=0.5)
        if data is None:
            return {}
            
        result = {
            "max_temp": data[0] - 40,  # °C with 40 offset
            "max_temp_number": data[1],
            "min_temp": data[2] - 40,  # °C with 40 offset
            "min_temp_number": data[3],
            "mos_temp": data[4],  # °C with 40 offset
            "board_temp": data[5],  # °C with 40 offset
            "temp_diff": data[6],#  # °C
        }
        
        #self._last_data.update(result)
        print(result)
        return result
        
    def get_mosfet_status(self) -> Dict[str, Union[float, int, str]]:
        """
        Get MOSFET status information
        
        Returns:
            Dict containing charge_discharge_status, charge_mos_status, 
                      discharge_mos_status, bms_life, remaining_capacity
        """
        data = _BMS_request.sendExtendedRequest(self.DATA_ID["MOSFET_STATUS"],self.DATA_ID_REPLY["MOSFET_STATUS"], timeout = 0.5)
        if data is None:
            return {}
            
        charge_discharge_state = data[0]
        if charge_discharge_state == 0:
            state_str = "stationary"
        elif charge_discharge_state == 1:
            state_str = "charging"
        elif charge_discharge_state == 2:
            state_str = "discharging"
        else:
            state_str = "unknown"
            
        result = {
            "charge_discharge_status": charge_discharge_state,
            "charge_discharge_status_str": state_str,
            "charge_mos_status": data[1],  # 0=off, 1=on
            "discharge_mos_status": data[2],  # 0=off, 1=on
            "bms_life": data[3],  # 0-255 cycles
            "remaining_capacity": struct.unpack(">I", data[4:8])[0]  # mAh
        }
        
        #self._last_data.update(result)
        print(result)
        return result
        
#     def get_status_info(self) -> Dict[str, Union[int, bool]]:
#         """
#         Get status information
#         
#         Returns:
#             Dict containing battery_strings, temperature_sensors, 
#                       charger_status, load_status, etc.
#         """
#         data = _BMS_request.sendExtendedRequest(self.DATA_ID["STATUS_INFO"],self.DATA_ID_REPLY["STATUS_INFO"],timeout = 0.5)
#         if data is None:
#             return {}
#             
#         # Digital IO states (byte 4)
#         dio_byte = data[4]
#         di_states = [bool(dio_byte & (1 << i)) for i in range(4)]
#         do_states = [bool(dio_byte & (1 << (i+4))) for i in range(4)]
#             
#         result = {
#             "battery_strings": data[0],
#             "temperature_sensors": data[1],
#             "charger_status": bool(data[2]),  # 0=disconnected, 1=connected
#             "load_status": bool(data[3]),  # 0=disconnected, 1=connected
#             "di1_status": di_states[0],
#             "di2_status": di_states[1],
#             "di3_status": di_states[2],
#             "di4_status": di_states[3],
#             "do1_status": do_states[0],
#             "do2_status": do_states[1],
#             "do3_status": do_states[2],
#             "do4_status": do_states[3],
#             "cycles": struct.unpack(">H", data[5:7])[0]
#         }
#         
#         self._last_data.update(result)
#         return result
    
    def get_all_cell_voltages(self) -> Dict[str, List[int]]:
        """
        Get all individual cell voltages
        
        Returns:
            Dict with "cell_voltages" containing a list of voltages in mV
        """
        result = {"cell_voltages": []}
        
        # According to protocol, cell voltages can span multiple frames
        # Let's request multiple frames if needed
        for frame_num in range(8):  # Assuming max 8 frames (48 cells)
            # Wait a bit between frames
            if frame_num > 0:
                time.sleep(0.1)
                
            data = _BMS_request.sendExtendedRequest(self.DATA_ID["CELL_VOLTAGES_RANGE"],self.DATA_ID_REPLY["CELL_VOLTAGES_RANGE"], timeout = 0.5)
            if data is None or data[0] == 0xFF:  # 0xFF indicates invalid frame
                break
                
            # Each frame contains up to 3 cell voltages (2 bytes each)
            current_frame = data[0]
            for i in range(3):
                if len(data) >= (i*2+3):  # Ensure we have enough data
                    cell_voltage = struct.unpack(">H", data[i*2+1:i*2+3])[0]
                    result["cell_voltages"].append(cell_voltage)
                    
            # If we've read all the cells based on the battery_strings value
            #if "battery_strings" in self._last_data:
            #    if len(result["cell_voltages"]) >= self._last_data["battery_strings"]:
            #        break
        print(result)            
        return result
    
    def get_all_temperatures(self) -> Dict[str, List[int]]:
        """
        Get all temperature sensor values
        
        Returns:
            Dict with "temperatures" containing a list of temperatures in °C
        """
        result = {"temperatures": []}
        
        # Similar to cell voltages, temperatures can span multiple frames
        for frame_num in range(3):  # Protocol mentions max 3 frames
            # Wait a bit between frames
            if frame_num > 0:
                time.sleep(0.1)
                
            data = _BMS_request.sendExtendedRequest(self.DATA_ID["TEMPERATURE_RANGE"],self.DATA_ID_REPLY["TEMPERATURE_RANGE"],timeout=0.5)
            if data is None or data[0] == 0xFF:  # 0xFF indicates invalid frame
                break
                
            # Each frame contains up to 7 temperatures (1 byte each)
            current_frame = data[0]
            for i in range(7):
                if len(data) >= (i+2):  # Ensure we have enough data
                    temp = data[i+1] - 40  # Apply offset
                    result["temperatures"].append(temp)
                    
            # If we've read all the temperature sensors
            if "temperature_sensors" in self._last_data:
                if len(result["temperatures"]) >= self._last_data["temperature_sensors"]:
                    break
        print(result)            
        return result
    
    def get_balance_status(self) -> Dict[str, List[bool]]:
        """
        Get cell balance status
        
        Returns:
            Dict with "balance_status" containing a list of boolean values
            indicating balance state for each cell
        """
        data = _BMS_request.sendExtendedRequest(self.DATA_ID["BALANCE_STATE"],self.DATA_ID_REPLY["BALANCE_STATE"],timeout=0.5)
        if data is None:
            return {"balance_status": []}
            
        # Parse balance status bits (0=closed, 1=open)
        balance_status = []
        for byte_index in range(1, 7):  # 6 bytes of balance data
            if byte_index < len(data):
                byte_val = data[byte_index]
                for bit in range(8):
                    balance_status.append(bool(byte_val & (1 << bit)))
        print("balance_status:", balance_status)            
        return {"balance_status": balance_status}
    
    def get_failure_status(self) -> Dict[str, bool]:
        """
        Get detailed failure status information
        
        Returns:
            Dict containing all possible failure states as boolean values
        """
        data = _BMS_request.sendExtendedRequest(self.DATA_ID["FAILURE_STATUS"],self.DATA_ID_REPLY["FAILURE_STATUS"],timeout = 0.5)
        if data is None:
            return {}
            
        # This is a very extensive status with many fields
        # Let's process all the bytes according to the protocol
        
        # Byte 0 - Cell/voltage failures
        result = {
            "cell_volt_high_1": bool(data[0] & 0x01),
            "cell_volt_high_2": bool(data[0] & 0x02),
            "cell_volt_low_1": bool(data[0] & 0x04),
            "cell_volt_low_2": bool(data[0] & 0x08),
            "sum_volt_high_1": bool(data[0] & 0x10),
            "sum_volt_high_2": bool(data[0] & 0x20),
            "sum_volt_low_1": bool(data[0] & 0x40),
            "sum_volt_low_2": bool(data[0] & 0x80),
        }
        
        # Byte 1 - Temperature failures
        if len(data) > 1:
            result.update({
                "chg_temp_high_1": bool(data[1] & 0x01),
                "chg_temp_high_2": bool(data[1] & 0x02),
                "chg_temp_low_1": bool(data[1] & 0x04),
                "chg_temp_low_2": bool(data[1] & 0x08),
                "dischg_temp_high_1": bool(data[1] & 0x10),
                "dischg_temp_high_2": bool(data[1] & 0x20),
                "dischg_temp_low_1": bool(data[1] & 0x40),
                "dischg_temp_low_2": bool(data[1] & 0x80),
            })
        
        # Byte 2 - Current and SOC failures
        if len(data) > 2:
            result.update({
                "chg_overcurrent_1": bool(data[2] & 0x01),
                "chg_overcurrent_2": bool(data[2] & 0x02),
                "dischg_overcurrent_1": bool(data[2] & 0x04),
                "dischg_overcurrent_2": bool(data[2] & 0x08),
                "soc_high_1": bool(data[2] & 0x10),
                "soc_high_2": bool(data[2] & 0x20),
                "soc_low_1": bool(data[2] & 0x40),
                "soc_low_2": bool(data[2] & 0x80),
            })
        
        # Byte 3 - Difference failures
        if len(data) > 3:
            result.update({
                "diff_volt_1": bool(data[3] & 0x01),
                "diff_volt_2": bool(data[3] & 0x02),
                "diff_temp_1": bool(data[3] & 0x04),
                "diff_temp_2": bool(data[3] & 0x08),
            })
        
        # Byte 4 - MOS failures
        if len(data) > 4:
            result.update({
                "chg_mos_temp_high": bool(data[4] & 0x01),
                "dischg_mos_temp_high": bool(data[4] & 0x02),
                "chg_mos_temp_sensor_err": bool(data[4] & 0x04),
                "dischg_mos_temp_sensor_err": bool(data[4] & 0x08),
                "chg_mos_adhesion_err": bool(data[4] & 0x10),
                "dischg_mos_adhesion_err": bool(data[4] & 0x20),
                "chg_mos_open_circuit_err": bool(data[4] & 0x40),
                "dischg_mos_open_circuit_err": bool(data[4] & 0x80),
            })
        
        # Byte 5 - Other failures
        if len(data) > 5:
            result.update({
                "afe_collect_chip_err": bool(data[5] & 0x01),
                "voltage_collect_dropped": bool(data[5] & 0x02),
                "cell_temp_sensor_err": bool(data[5] & 0x04),
                "eeprom_err": bool(data[5] & 0x08),
                "rtc_err": bool(data[5] & 0x10),
                "precharge_failure": bool(data[5] & 0x20),
                "communication_failure": bool(data[5] & 0x40),
                "internal_communication_failure": bool(data[5] & 0x80),
            })
        
        # Byte 6 - Additional failures
        if len(data) > 6:
            result.update({
                "current_module_fault": bool(data[6] & 0x01),
                "sum_voltage_detect_fault": bool(data[6] & 0x02),
                "short_circuit_protect_fault": bool(data[6] & 0x04),
                "low_volt_forbidden_chg_fault": bool(data[6] & 0x08),
                "gps_or_soft_switch_disconnects_mos": bool(data[6] & 0x10),
                "charging_cabinet_offline": bool(data[6] & 0x20),
                "thermal_runaway_fault": bool(data[6] & 0x40),
            })
        
        # Byte 7 - Fault code
        if len(data) > 7 and data[7] != 0:
            result["fault_code"] = data[7]
        print(result)     
        return result
    
    def control_discharge_mos(self, turn_on=True) -> bool:
        """
        Control the Discharge MOSFET
        
        Args:
            turn_on: True to turn on, False to turn off
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Prepare command data
        data = bytearray([0x01 if turn_on else 0x00] + [0x00] * 7)
        
        # Send the command
        return _BMS_request.sendExtendedRequest(self.DATA_ID["DISCHARGE_MOS_CONTROL"], data) #NOT YET IMPLEMENTED FOR WRITING 
    
    def control_charge_mos(self, turn_on=True) -> bool:
        """
        Control the Charge MOSFET
        
        Args:
            turn_on: True to turn on, False to turn off
            
        Returns:
            bool: True if successful, False otherwise
        """
        # Prepare command data
        data = bytearray([0x01 if turn_on else 0x00] + [0x00] * 7)
        
        # Send the command
        return _BMS_request.sendExtendedRequest(self.DATA_ID["CHARGE_MOS_CONTROL"], data) #NOT YET IMPLEMENTED FOR WRITING 
    
    def get_all_data(self) -> Dict[str, any]:
        """
        Get all BMS data in one go
        
        Returns:
            Dict containing all BMS data
        """
        result = {}
        
        # Request all basic data types
        result.update(self.get_basic_info())
        result.update(self.get_cell_voltages())
        result.update(self.get_temperatures())
        result.update(self.get_mosfet_status())
        result.update(self.get_status_info())
        
        # Get additional details if available
        if "battery_strings" in result and result["battery_strings"] > 0:
            result.update(self.get_all_cell_voltages())
            
        if "temperature_sensors" in result and result["temperature_sensors"] > 0:
            result.update(self.get_all_temperatures())
            
        result.update(self.get_balance_status())
        result.update(self.get_failure_status())
        
        return result

# finally:
#     # Clean up
#     can.cleanup()
#     print("CAN interface closed")

